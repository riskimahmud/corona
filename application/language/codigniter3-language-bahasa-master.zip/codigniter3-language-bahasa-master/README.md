CodeIgniter 3 Language Pack : Bahasa
==========
Dukungan Bahasa Indonesia untuk CodeIgniter Versi : 3.0.0

Instalasi:
==========
1. Download <strong><a target="_blank" href="https://github.com/warizzmann/codigniter-language-bahasa/archive/master.zip">disini</a></strong>
2. Paste folder <strong>bahasa</strong> pada direktori <strong>application/language</strong>'
3. Ubah pengaturan bahasa pada <strong>'application/config/config.php'</strong> <br>
   <code>$config['language']	= 'bahasa';</code>

Homepage
========
<a target="_blank" href="http://warizzmann.github.io/codigniter3-language-bahasa">Codigniter 3 language pack : bahasa indonesia</a>

Jika error berlanjut, hubungi:
========
<strong>Warisman Syam</strong>
(warizzmann@gmail.com)
